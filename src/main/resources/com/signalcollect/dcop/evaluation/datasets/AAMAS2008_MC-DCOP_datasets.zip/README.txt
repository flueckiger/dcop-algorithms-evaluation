The graph*.dat files were designed to be used with the MC-MGM algorithm by the Teamcore research group at the University of Southern California. The graphgen.java file included can generate random graphs based on parameters listed in the comments of that file. The included .dat files have a comment line following the VARIABLE lines, which lists the parameters used to generate that graph. Here is an example:

#numAgents	1000	domainSize	3	density	3.0	methodType	1	gBudgetRange	50	gCostScaler	1.2	gBudgetCreationMethod	0	gCostCreationMethod	11	k	2	numGConstraints	4
